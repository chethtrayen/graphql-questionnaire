import { GraphQLContext } from "./graphql";
import { User } from "./user";

export type Context = GraphQLContext<User>;
